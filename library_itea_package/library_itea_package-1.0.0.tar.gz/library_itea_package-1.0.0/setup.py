from setuptools import setup

setup(
    name='library_itea_package',
    version='1.0.0',
    description='A library itea for test',
    author='I =)',
    author_email='test@test.com',
    packages=['library_itea_package', 'library_itea_package.utils'],
    install_requires=['numpy']
)