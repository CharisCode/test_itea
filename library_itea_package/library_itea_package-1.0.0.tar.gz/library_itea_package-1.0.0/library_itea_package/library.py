from library_itea_package.utils.reader import Reader
from library_itea_package.utils.book import Book


class Library:
    print(f'class Library: {Book}')
    print(f'class Library: {Reader}')