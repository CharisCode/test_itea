from library_itea_package.library import Library

import numpy as np
from random import randint

print(np.array( [randint(0, 10) for i in range(10)] ))

lib = Library()