from library_itea_package.utils.reader import Reader


class Book:
    print(f'class Book: {Reader}')
