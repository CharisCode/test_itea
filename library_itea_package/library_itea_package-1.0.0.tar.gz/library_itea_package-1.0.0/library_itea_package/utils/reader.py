class Reader:
    pass